package com.innophil.app.triggers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.innophil.app.service.GuardianService

/**
 * ACTION_SHUTDOWN is a best-effort broadcast: the OS gives apps a very
 * short window to react before power actually cuts. Manufacturer skins
 * vary in how reliably they deliver it and how much time they allow.
 * Treat this as "the phone was ASKED to power off" - a genuine hardware
 * power-off (e.g. battery pulled, or already off) cannot be intercepted;
 * see our earlier conversation on that hard limit.
 */
class ShutdownReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_SHUTDOWN) return
        GuardianService.reportShutdownAttempt(context)
    }
}
