package com.innophil.app.admin

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import com.innophil.app.service.GuardianService

/**
 * Requesting Device Admin (rather than only runtime permissions) is what
 * unlocks three things we discussed:
 *   1. onPasswordFailed() below - a real OS callback that fires on every
 *      wrong PIN/pattern/password attempt on the lock screen. This is the
 *      "wrong PIN" trigger - no polling or guessing required.
 *   2. lockNow() / wipeData() - for the remote "lock phone" / "wipe phone"
 *      dashboard buttons.
 *   3. The remote Wi-Fi-on pathway is more privileged than a plain app;
 *      see network/NetworkStateReceiver for the caveats that still apply.
 */
class InnoPhilDeviceAdminReceiver : DeviceAdminReceiver() {

    companion object {
        fun componentName(context: Context): ComponentName =
            ComponentName(context, InnoPhilDeviceAdminReceiver::class.java)

        fun isActive(context: Context): Boolean {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            return dpm.isAdminActive(componentName(context))
        }

        fun lockNow(context: Context) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (isActive(context)) dpm.lockNow()
        }

        /** Irreversible. Only ever call this from a confirmed, authenticated remote command. */
        fun wipeData(context: Context) {
            val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            if (isActive(context)) dpm.wipeData(0)
        }
    }

    override fun onEnabled(context: Context, intent: Intent) {
        super.onEnabled(context, intent)
        GuardianService.start(context, reason = "device_admin_enabled")
    }

    override fun onPasswordFailed(context: Context, intent: Intent) {
        super.onPasswordFailed(context, intent)
        // This is the real "wrong PIN entered" trigger.
        // We deliberately do NOT capture on the very first failed attempt
        // (people fumble their own PIN often) - the threshold lives in
        // GuardianService so it's configurable in one place.
        GuardianService.reportFailedUnlock(context)
    }

    override fun onPasswordSucceeded(context: Context, intent: Intent) {
        super.onPasswordSucceeded(context, intent)
        GuardianService.reportSuccessfulUnlock(context)
    }
}
