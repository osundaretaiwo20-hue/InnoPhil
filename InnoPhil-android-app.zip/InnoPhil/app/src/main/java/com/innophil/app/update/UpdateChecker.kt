package com.innophil.app.update

import android.content.Context
import android.util.Log
import com.innophil.app.BuildConfig
import com.innophil.app.util.Prefs
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

data class UpdateInfo(
    val versionTag: String,
    val downloadUrl: String,
    val releaseNotes: String
)

/**
 * Checks GitHub's Releases API for a newer build than the one currently
 * installed. This is the "self-hosted Play Store check" we discussed:
 * every time we push a code change, the build.yml workflow publishes a
 * new GitHub Release with the freshly-built APK attached, tagged with a
 * version number. This class just asks "what's the latest tag, and is it
 * newer than what I'm running?"
 *
 * Requires the repo ("yourusername/InnoPhil") to be set on the setup
 * screen and saved via Prefs.setGithubRepo - without that, this silently
 * does nothing rather than crashing.
 */
object UpdateChecker {

    private const val TAG = "UpdateChecker"

    fun checkForUpdate(context: Context, onResult: (UpdateInfo?) -> Unit) {
        val repo = Prefs.getGithubRepo(context)
        if (repo.isNullOrBlank()) {
            onResult(null)
            return
        }

        Thread {
            try {
                val client = OkHttpClient()
                val request = Request.Builder()
                    .url("https://api.github.com/repos/$repo/releases/latest")
                    .header("Accept", "application/vnd.github+json")
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        Log.w(TAG, "Release check failed: ${response.code}")
                        onResult(null)
                        return@use
                    }

                    val body = response.body?.string() ?: return@use onResult(null)
                    val json = JSONObject(body)
                    val tagName = json.optString("tag_name", "")
                    val notes = json.optString("body", "")

                    val assets = json.optJSONArray("assets")
                    var apkUrl: String? = null
                    if (assets != null) {
                        for (i in 0 until assets.length()) {
                            val asset = assets.getJSONObject(i)
                            val name = asset.optString("name", "")
                            if (name.endsWith(".apk")) {
                                apkUrl = asset.optString("browser_download_url")
                                break
                            }
                        }
                    }

                    if (apkUrl != null && isNewer(tagName, BuildConfig.VERSION_NAME)) {
                        onResult(UpdateInfo(tagName, apkUrl, notes))
                    } else {
                        onResult(null)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Update check failed (expected while offline)", e)
                onResult(null)
            }
        }.start()
    }

    /**
     * Simple string comparison is NOT reliable for versions ("v10" < "v9"
     * alphabetically). We tag releases as build numbers (see build.yml -
     * "v" + GitHub run number), so this strips the "v" and compares
     * numerically. Extend this if you switch to semantic versioning later.
     */
    private fun isNewer(remoteTag: String, localVersionName: String): Boolean {
        val remoteNum = remoteTag.removePrefix("v").toIntOrNull() ?: return false
        val localNum = localVersionName.removePrefix("v").toIntOrNull() ?: 0
        return remoteNum > localNum
    }
}
