package com.innophil.app.sms

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.telephony.SmsManager
import android.util.Log
import com.innophil.app.util.Prefs

/**
 * Text-only alert. Deliberately kept separate from the photo/video pipeline
 * because SMS has no capacity for attachments - see our earlier discussion.
 * This works as long as whatever SIM is CURRENTLY in the phone has any
 * carrier signal at all - it does not require your original MTN SIM
 * specifically, and does not require a data plan or Wi-Fi.
 */
object SmsAlertSender {

    private const val TAG = "SmsAlertSender"

    @SuppressLint("MissingPermission") // caller must have already checked SEND_SMS
    fun sendTheftAlert(context: Context, reason: String, location: Location?) {
        val backupNumber = Prefs.getBackupPhoneNumber(context) ?: run {
            Log.w(TAG, "No backup number configured, cannot send SMS alert")
            return
        }

        val locationText = if (location != null) {
            "https://maps.google.com/?q=${location.latitude},${location.longitude}"
        } else {
            "location unavailable"
        }

        val message = "InnoPhil alert: $reason. Last known location: $locationText " +
            "at ${System.currentTimeMillis()}"

        try {
            val smsManager = context.getSystemService(SmsManager::class.java)
                ?: SmsManager.getDefault()
            val parts = smsManager.divideMessage(message)
            smsManager.sendMultipartTextMessage(backupNumber, null, parts, null, null)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send SMS alert", e)
        }
    }
}
