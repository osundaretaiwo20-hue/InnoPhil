package com.innophil.app.capture

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Short ambient audio clip recorder.
 *
 * LEGAL REMINDER (this is not a coding limitation, it's a law one - see
 * our earlier conversation): several jurisdictions require ALL parties to
 * a conversation to consent before it's recorded. Recording is generally
 * far more defensible when it captures YOUR OWN stolen property's
 * surroundings for evidence than as a blanket "always listening" feature.
 * Consider keeping this OFF by default and only triggered manually from
 * the dashboard, not on every wrong-PIN attempt automatically.
 */
class AudioCaptureHelper(private val context: Context) {

    private var recorder: MediaRecorder? = null
    private var outputFile: File? = null

    fun startRecording(outputDir: File, maxDurationMs: Int = 30_000, onStopped: (File?) -> Unit) {
        if (!outputDir.exists()) outputDir.mkdirs()

        val filename = "audio_${
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        }.m4a"
        val file = File(outputDir, filename)
        outputFile = file

        try {
            recorder = (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(file.absolutePath)
                setMaxDuration(maxDurationMs)
                setOnInfoListener { _, what, _ ->
                    if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) {
                        stopRecording(onStopped)
                    }
                }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Audio recording failed to start", e)
            onStopped(null)
        }
    }

    fun stopRecording(onStopped: (File?) -> Unit) {
        try {
            recorder?.stop()
            recorder?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recorder", e)
        } finally {
            recorder = null
            onStopped(outputFile)
        }
    }

    companion object {
        private const val TAG = "AudioCaptureHelper"
    }
}
