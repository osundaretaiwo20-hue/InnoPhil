package com.innophil.app

import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.innophil.app.admin.InnoPhilDeviceAdminReceiver
import com.innophil.app.service.GuardianService
import com.innophil.app.update.ApkInstaller
import com.innophil.app.update.UpdateChecker
import com.innophil.app.util.PermissionsHelper
import com.innophil.app.util.Prefs

/**
 * One-time onboarding. Deliberately explicit and step-by-step rather than
 * auto-requesting everything at once - both because Android requires
 * runtime confirmation for sensitive permissions anyway, and because being
 * upfront about what this app does and why is what keeps it on the right
 * side of the "consent tool for your own device" vs "stalkerware" line
 * we discussed.
 */
class SetupActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val allGranted = results.values.all { it }
        statusText.text = if (allGranted) {
            "Permissions granted. Now enable Device Admin."
        } else {
            "Some permissions were denied - InnoPhil needs all of them to work fully."
        }
    }

    private val deviceAdminLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        statusText.text = if (InnoPhilDeviceAdminReceiver.isActive(this)) {
            "Device Admin enabled. You can now save and start protection."
        } else {
            "Device Admin was not enabled - the wrong-PIN trigger and remote lock/wipe won't work without it."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setup)

        statusText = findViewById(R.id.statusText)
        val inputBackupNumber = findViewById<EditText>(R.id.inputBackupNumber)
        val inputBackendUrl = findViewById<EditText>(R.id.inputBackendUrl)
        val inputGithubRepo = findViewById<EditText>(R.id.inputGithubRepo)

        Prefs.getBackupPhoneNumber(this)?.let { inputBackupNumber.setText(it) }
        Prefs.getBackendUrl(this)?.let { inputBackendUrl.setText(it) }
        Prefs.getGithubRepo(this)?.let { inputGithubRepo.setText(it) }

        findViewById<Button>(R.id.btnCheckUpdate).setOnClickListener {
            val repo = inputGithubRepo.text.toString().trim()
            if (repo.isEmpty()) {
                statusText.text = "Enter your GitHub repo first, e.g. yourusername/InnoPhil"
                return@setOnClickListener
            }
            Prefs.setGithubRepo(this, repo)
            statusText.text = "Checking for updates..."
            UpdateChecker.checkForUpdate(this) { update ->
                runOnUiThread {
                    if (update == null) {
                        statusText.text = "You're on the latest version."
                    } else {
                        statusText.text = "Update ${update.versionTag} found. Downloading..."
                        ApkInstaller.downloadAndInstall(this, update)
                    }
                }
            }
        }

        findViewById<Button>(R.id.btnGrantPermissions).setOnClickListener {
            if (PermissionsHelper.allGranted(this)) {
                statusText.text = "All permissions already granted."
            } else {
                permissionLauncher.launch(PermissionsHelper.missing(this).toTypedArray())
            }
        }

        findViewById<Button>(R.id.btnEnableDeviceAdmin).setOnClickListener {
            if (InnoPhilDeviceAdminReceiver.isActive(this)) {
                statusText.text = "Device Admin already active."
            } else {
                val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                    putExtra(
                        DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                        InnoPhilDeviceAdminReceiver.componentName(this@SetupActivity)
                    )
                    putExtra(
                        DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "InnoPhil needs this to detect wrong unlock attempts and to lock/wipe the phone remotely if it's stolen."
                    )
                }
                deviceAdminLauncher.launch(intent)
            }
        }

        findViewById<Button>(R.id.btnFinishSetup).setOnClickListener {
            val number = inputBackupNumber.text.toString().trim()
            val backendUrl = inputBackendUrl.text.toString().trim()

            if (number.isEmpty()) {
                statusText.text = "Enter a backup phone number first."
                return@setOnClickListener
            }
            if (!PermissionsHelper.allGranted(this)) {
                statusText.text = "Grant all permissions before starting protection."
                return@setOnClickListener
            }

            Prefs.setBackupPhoneNumber(this, number)
            if (backendUrl.isNotEmpty()) Prefs.setBackendUrl(this, backendUrl)
            Prefs.setSetupComplete(this, true)

            GuardianService.start(this, reason = "setup_complete")
            statusText.text = "Protection is active."
        }

        // Silent auto-check every time you open the app - this is the
        // "just reopen it and it tells you" behavior we discussed. It only
        // speaks up if an update actually exists; otherwise it says nothing.
        if (!Prefs.getGithubRepo(this).isNullOrBlank()) {
            UpdateChecker.checkForUpdate(this) { update ->
                if (update != null) {
                    runOnUiThread {
                        statusText.text = "Update ${update.versionTag} available - downloading..."
                        ApkInstaller.downloadAndInstall(this, update)
                    }
                }
            }
        }
    }
}
