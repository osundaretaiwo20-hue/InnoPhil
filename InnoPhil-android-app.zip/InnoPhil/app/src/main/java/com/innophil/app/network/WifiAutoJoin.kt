package com.innophil.app.network

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat

object WifiAutoJoin {

    private const val TAG = "WifiAutoJoin"

    /**
     * Turns Wi-Fi on directly. Only works on Android 9 (API 28) and below -
     * Google removed WifiManager.setWifiEnabled() for third-party apps
     * starting Android 10. On 10+ this call silently becomes a no-op that
     * returns false; we log it rather than pretend it worked.
     */
    fun attemptForceWifiOn(context: Context): Boolean {
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
            Log.w(TAG, "Cannot silently enable Wi-Fi on Android 10+; needs remote Device Admin command or user action")
            return false
        }
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        return wifiManager.setWifiEnabled(true)
    }

    /**
     * If Wi-Fi is already on (by user, by the pre-Android-10 path above, or
     * by a remote Device Admin command - see admin/InnoPhilDeviceAdminReceiver),
     * this nudges the system to (re)connect to whatever known/open network
     * is in range. On modern Android, joining a NEW open network
     * programmatically without user interaction is restricted (Android 10+
     * requires the network suggestion API with user approval for anything
     * that wasn't previously joined) - but reconnecting to a network the
     * phone has joined before happens automatically at the OS level once
     * Wi-Fi is on, with no app code needed.
     */
    fun attemptJoinKnownOrOpenNetwork(context: Context) {
        val wifiManager = context.applicationContext
            .getSystemService(Context.WIFI_SERVICE) as WifiManager
        if (!wifiManager.isWifiEnabled) {
            attemptForceWifiOn(context)
            return
        }
        // Nothing further to do here on modern Android: reconnection to a
        // previously-known network is handled by the OS automatically.
        // For joining brand-new open networks, use WifiNetworkSuggestion
        // (API 29+) — left as a documented extension point rather than
        // built here, since it requires a user-visible approval step the
        // first time and isn't truly silent.
    }
}
