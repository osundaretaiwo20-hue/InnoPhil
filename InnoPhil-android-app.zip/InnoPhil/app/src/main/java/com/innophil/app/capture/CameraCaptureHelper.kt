package com.innophil.app.capture

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Captures a still photo with no viewfinder shown and no shutter sound
 * queued for playback (see suppressShutterSound note below). This must be
 * bound to a LifecycleOwner - GuardianService implements LifecycleOwner
 * itself (a "headless" lifecycle that's just always STARTED) so capture
 * can run from a background service instead of a visible Activity.
 *
 * Front camera = likely captures the thief's face if they're holding
 * the phone up to unlock it. Rear camera = captures surroundings.
 * GuardianService can call both in sequence.
 */
class CameraCaptureHelper(private val context: Context) {

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null

    fun initialize(lifecycleOwner: LifecycleOwner, useFrontCamera: Boolean, onReady: () -> Unit) {
        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()

            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            val selector = if (useFrontCamera) {
                CameraSelector.DEFAULT_FRONT_CAMERA
            } else {
                CameraSelector.DEFAULT_BACK_CAMERA
            }

            try {
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(lifecycleOwner, selector, imageCapture)
                onReady()
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed", e)
            }
        }, ContextCompat.getMainExecutor(context))
    }

    fun captureTo(outputDir: File, onSaved: (File?) -> Unit) {
        val capture = imageCapture ?: return onSaved(null)
        if (!outputDir.exists()) outputDir.mkdirs()

        val filename = "capture_${
            SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(System.currentTimeMillis())
        }.jpg"
        val file = File(outputDir, filename)
        val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()

        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    onSaved(file)
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e(TAG, "Capture failed", exception)
                    onSaved(null)
                }
            }
        )
    }

    fun release() {
        cameraProvider?.unbindAll()
    }

    companion object {
        private const val TAG = "CameraCaptureHelper"

        // HONEST CAVEAT (do not remove this comment):
        // Some manufacturer camera stacks (notably Samsung and some MIUI/HyperOS
        // builds) play a shutter sound at the hardware/HAL level regardless of
        // ringer/silent mode, specifically as an anti-voyeurism measure in
        // certain regions (e.g. South Korea/Japan requires it by regulation on
        // any phone sold there, no exceptions). CameraX/Camera2 cannot suppress
        // this from app code on those builds. Test on the actual target device
        // before relying on "silent" capture.
    }
}
