package com.innophil.app.network

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

/**
 * Fires whenever connectivity changes. This is the hook for "the moment
 * there's a flicker of signal, act on it" behavior we discussed:
 *   - flush anything queued in the UploadWorker backlog
 *   - (see WifiAutoJoin) attempt to join any known/open network
 *
 * HONEST CAVEAT: since Android 10, apps cannot silently turn Wi-Fi on by
 * themselves in the background - that path is closed by Google specifically
 * to prevent apps like this one from behaving like malware. What still
 * works: if Wi-Fi is already ON, silently connecting to a known or open
 * network is fine. Forcing Wi-Fi ON itself needs either (a) the user
 * doing it, (b) a remote command executed via Device Policy Manager
 * while the phone still has SOME connectivity to receive that command,
 * or (c) an older/Android 9-and-below device. See WifiAutoJoin.kt.
 */
class NetworkStateReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val request = OneTimeWorkRequestBuilder<UploadWorker>().build()
        WorkManager.getInstance(context).enqueue(request)

        WifiAutoJoin.attemptJoinKnownOrOpenNetwork(context)
    }
}
