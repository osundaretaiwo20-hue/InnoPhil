package com.innophil.app.remote

import android.content.Context
import android.util.Log
import com.innophil.app.admin.InnoPhilDeviceAdminReceiver
import com.innophil.app.service.GuardianService
import com.innophil.app.util.Prefs
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

/**
 * STUB - this is the piece that talks to the backend/website we discussed
 * but have NOT built yet. Two real implementation choices once that
 * exists:
 *
 *   1. Push-based (recommended): backend sends a Firebase Cloud Messaging
 *      "data message" the instant you press a button on the dashboard.
 *      Near-instant, and doesn't need the phone to keep asking "any
 *      commands for me?" - lower battery cost. Requires wiring
 *      FirebaseMessagingService into this project once the backend exists.
 *
 *   2. Poll-based (what's stubbed below): the phone periodically asks the
 *      backend "any pending commands?" - simpler to stand up first, works
 *      with literally any backend language/framework, but adds delay
 *      (only as fast as the poll interval) and background battery use.
 *
 * Recommendation: start with polling to get end-to-end capture -> upload
 * -> dashboard working, then swap in FCM once the backend is live.
 */
object CommandPoller {

    private const val TAG = "CommandPoller"

    fun pollOnce(context: Context) {
        val backendUrl = Prefs.getBackendUrl(context) ?: return
        val token = Prefs.getDeviceToken(context) ?: return

        try {
            val client = OkHttpClient()
            val request = Request.Builder()
                .url("$backendUrl/api/commands/pending")
                .header("Authorization", "Bearer $token")
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return
                val body = response.body?.string() ?: return
                val json = JSONObject(body)
                val command = json.optString("command", "")
                dispatch(context, command)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Command poll failed (expected while offline)", e)
        }
    }

    private fun dispatch(context: Context, command: String) {
        when (command) {
            "capture_now" -> GuardianService.reportRemoteCaptureRequest(context)
            "lock_now" -> InnoPhilDeviceAdminReceiver.lockNow(context)
            "wipe_now" -> InnoPhilDeviceAdminReceiver.wipeData(context)
            "" -> Unit // nothing pending
            else -> Log.w(TAG, "Unknown remote command: $command")
        }
    }
}
