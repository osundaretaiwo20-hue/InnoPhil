package com.innophil.app.triggers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import com.innophil.app.service.GuardianService
import com.innophil.app.util.Prefs

/**
 * Fires on Android's SIM_STATE_CHANGED broadcast. We compare the current
 * SIM's ICCID against the one recorded during setup (Prefs.getKnownIccid).
 * A mismatch = someone swapped SIMs, which is one of our three triggers.
 *
 * Note: reading ICCID requires READ_PHONE_STATE and, on Android 10+,
 * additionally reading it via SubscriptionManager per-slot for dual-SIM
 * phones - simplified here to single-SIM for clarity. Extend for dual-SIM
 * devices as needed.
 */
class SimChangeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != "android.intent.action.SIM_STATE_CHANGED") return

        val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val currentIccid = try {
            @Suppress("MissingPermission")
            tm.simSerialNumber
        } catch (e: SecurityException) {
            null
        }

        val knownIccid = Prefs.getKnownIccid(context)

        if (currentIccid != null && knownIccid != null && currentIccid != knownIccid) {
            GuardianService.reportSimSwap(context, newIccid = currentIccid)
        } else if (currentIccid != null && knownIccid == null) {
            // First run: nothing to compare against yet, just record it.
            Prefs.setKnownIccid(context, currentIccid)
        }
    }
}
