package com.innophil.app.network

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.innophil.app.util.Prefs
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File

/**
 * The offline-tolerant delivery queue described in our conversation:
 * captures are written to CAPTURE_QUEUE_DIR immediately (fully offline-safe),
 * and this worker is what actually ships them out - triggered by
 * NetworkStateReceiver whenever connectivity changes, and also scheduled
 * periodically by GuardianService as a backstop.
 *
 * WorkManager itself already handles "retry with backoff until it
 * succeeds," which is why this is built on WorkManager rather than a
 * plain background thread.
 */
class UploadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val backendUrl = Prefs.getBackendUrl(applicationContext) ?: return Result.failure()
        val token = Prefs.getDeviceToken(applicationContext) ?: return Result.retry()

        val queueDir = File(applicationContext.filesDir, CAPTURE_QUEUE_DIR)
        if (!queueDir.exists()) return Result.success()

        val pending = queueDir.listFiles() ?: return Result.success()
        if (pending.isEmpty()) return Result.success()

        val client = OkHttpClient()

        for (file in pending) {
            try {
                val mediaType = when (file.extension) {
                    "jpg", "jpeg" -> "image/jpeg"
                    "m4a" -> "audio/mp4"
                    else -> "application/octet-stream"
                }.toMediaTypeOrNull()

                val body = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("file", file.name, file.asRequestBody(mediaType))
                    .build()

                val request = Request.Builder()
                    .url("$backendUrl/api/upload")
                    .header("Authorization", "Bearer $token")
                    .post(body)
                    .build()

                client.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        file.delete()
                    } else {
                        Log.w(TAG, "Upload failed (${response.code}) for ${file.name}, will retry later")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Upload error for ${file.name}, will retry later", e)
                // Leave the file queued; don't fail the whole worker over one file.
            }
        }

        return Result.success()
    }

    companion object {
        private const val TAG = "UploadWorker"
        const val CAPTURE_QUEUE_DIR = "innophil_queue"
    }
}
