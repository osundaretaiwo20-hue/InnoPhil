package com.innophil.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.innophil.app.SetupActivity
import com.innophil.app.capture.AudioCaptureHelper
import com.innophil.app.capture.CameraCaptureHelper
import com.innophil.app.network.UploadWorker
import com.innophil.app.sms.SmsAlertSender
import com.innophil.app.util.Prefs
import java.io.File

/**
 * Always-on foreground service. Android REQUIRES a visible notification
 * for any foreground service using the camera/microphone (this is an
 * OS-level transparency rule, not something we can turn off - see our
 * "secretly" discussion). The notification below is worded plainly rather
 * than disguised, since disguising it crosses into the stalkerware
 * territory Play Store policy and Android itself actively try to detect
 * and block. Keep it honest.
 */
class GuardianService : Service(), LifecycleOwner {

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    private lateinit var cameraHelper: CameraCaptureHelper
    private lateinit var audioHelper: AudioCaptureHelper

    private var failedUnlockCount = 0

    override fun onCreate() {
        super.onCreate()
        lifecycleRegistry.currentState = Lifecycle.State.CREATED
        cameraHelper = CameraCaptureHelper(this)
        audioHelper = AudioCaptureHelper(this)
        startForeground(NOTIFICATION_ID, buildNotification())
        lifecycleRegistry.currentState = Lifecycle.State.STARTED
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // START_STICKY: ask Android to restart us if the system kills us
        // under memory pressure. Not a guarantee on every OEM skin - some
        // (again, MIUI/HyperOS included) apply their own aggressive battery
        // optimization on top that can still kill background services;
        // guiding the user to disable battery optimization for this app
        // during setup is important in practice.
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        cameraHelper.release()
        lifecycleRegistry.currentState = Lifecycle.State.DESTROYED
        super.onDestroy()
    }

    // ---- Trigger entry points (called by the various receivers) ----

    private fun handleFailedUnlock() {
        failedUnlockCount++
        if (failedUnlockCount >= WRONG_PIN_THRESHOLD) {
            failedUnlockCount = 0
            captureAndQueue(reason = "wrong_pin_threshold_reached", useFrontCamera = true)
        }
    }

    private fun handleSuccessfulUnlock() {
        failedUnlockCount = 0
    }

    private fun handleSimSwap(newIccid: String) {
        Prefs.setKnownIccid(this, newIccid)
        captureAndQueue(reason = "sim_swapped", useFrontCamera = true)
        SmsAlertSender.sendTheftAlert(this, reason = "SIM card was swapped", location = lastKnownLocation())
    }

    private fun handleShutdownAttempt() {
        captureAndQueue(reason = "shutdown_attempted", useFrontCamera = true)
        SmsAlertSender.sendTheftAlert(this, reason = "Phone power-off was requested", location = lastKnownLocation())
    }

    private fun handleRemoteCaptureRequest() {
        captureAndQueue(reason = "remote_command", useFrontCamera = true)
    }

    private fun captureAndQueue(reason: String, useFrontCamera: Boolean) {
        cameraHelper.initialize(this, useFrontCamera) {
            val queueDir = File(filesDir, UploadWorker.CAPTURE_QUEUE_DIR)
            cameraHelper.captureTo(queueDir) { savedFile ->
                if (savedFile != null) {
                    // Immediately try to flush the queue; UploadWorker itself
                    // is offline-tolerant and will just leave the file queued
                    // if there's no connectivity yet.
                    WorkManager.getInstance(this).enqueue(OneTimeWorkRequestBuilder<UploadWorker>().build())
                }
            }
        }
    }

    private fun lastKnownLocation(): Location? {
        return try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            lm.getProviders(true)
                .mapNotNull { lm.getLastKnownLocation(it) }
                .maxByOrNull { it.time }
        } catch (e: SecurityException) {
            null
        }
    }

    private fun buildNotification(): Notification {
        val channelId = "innophil_guard_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "InnoPhil Protection",
                NotificationManager.IMPORTANCE_LOW
            )
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, SetupActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("InnoPhil is protecting this device")
            .setContentText("Tap to open settings")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 42
        private const val WRONG_PIN_THRESHOLD = 3

        fun start(context: Context, reason: String) {
            val intent = Intent(context, GuardianService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        // The trigger receivers call these instead of holding a direct
        // reference to a running instance, since the service may need to
        // be (re)started first.
        fun reportFailedUnlock(context: Context) = withRunningService(context) { it.handleFailedUnlock() }
        fun reportSuccessfulUnlock(context: Context) = withRunningService(context) { it.handleSuccessfulUnlock() }
        fun reportSimSwap(context: Context, newIccid: String) =
            withRunningService(context) { it.handleSimSwap(newIccid) }
        fun reportShutdownAttempt(context: Context) = withRunningService(context) { it.handleShutdownAttempt() }
        fun reportRemoteCaptureRequest(context: Context) =
            withRunningService(context) { it.handleRemoteCaptureRequest() }

        // Simplified binding shortcut. In production, prefer a bound
        // service or a static event bus over this pattern; left simple
        // here for scaffold readability.
        private var runningInstance: GuardianService? = null

        private fun withRunningService(context: Context, action: (GuardianService) -> Unit) {
            runningInstance?.let(action) ?: start(context, "trigger_fired_no_instance")
        }
    }

    init {
        runningInstance = this
    }
}
