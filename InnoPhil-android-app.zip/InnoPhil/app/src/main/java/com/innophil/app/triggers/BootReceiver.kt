package com.innophil.app.triggers

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.innophil.app.service.GuardianService
import com.innophil.app.util.Prefs

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        // A thief rebooting the phone to try to dodge lock screens/tracking
        // is exactly when this matters most - restart immediately.
        if (Prefs.isSetupComplete(context)) {
            GuardianService.start(context, reason = "boot_completed")
        }
    }
}
