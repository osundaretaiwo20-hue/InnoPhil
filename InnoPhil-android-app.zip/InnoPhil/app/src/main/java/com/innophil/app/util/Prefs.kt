package com.innophil.app.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Thin wrapper around SharedPreferences.
 *
 * NOTE: this is plaintext prefs for scaffold purposes. Before real use,
 * swap this for androidx.security.crypto's EncryptedSharedPreferences so the
 * backup number / backend URL / auth token aren't sitting in plaintext on disk.
 */
object Prefs {

    private const val FILE = "innophil_prefs"

    private fun sp(context: Context): SharedPreferences =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun setBackupPhoneNumber(context: Context, number: String) =
        sp(context).edit().putString("backup_number", number).apply()

    fun getBackupPhoneNumber(context: Context): String? =
        sp(context).getString("backup_number", null)

    fun setKnownIccid(context: Context, iccid: String) =
        sp(context).edit().putString("known_iccid", iccid).apply()

    fun getKnownIccid(context: Context): String? =
        sp(context).getString("known_iccid", null)

    fun setBackendUrl(context: Context, url: String) =
        sp(context).edit().putString("backend_url", url).apply()

    fun getBackendUrl(context: Context): String? =
        sp(context).getString("backend_url", null)

    fun setDeviceToken(context: Context, token: String) =
        sp(context).edit().putString("device_token", token).apply()

    fun getDeviceToken(context: Context): String? =
        sp(context).getString("device_token", null)

    /** Format: "yourusername/InnoPhil" - used by UpdateChecker to find your Releases. */
    fun setGithubRepo(context: Context, repo: String) =
        sp(context).edit().putString("github_repo", repo).apply()

    fun getGithubRepo(context: Context): String? =
        sp(context).getString("github_repo", null)

    fun setSetupComplete(context: Context, complete: Boolean) =
        sp(context).edit().putBoolean("setup_complete", complete).apply()

    fun isSetupComplete(context: Context): Boolean =
        sp(context).getBoolean("setup_complete", false)
}
