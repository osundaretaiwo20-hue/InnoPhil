# InnoPhil — Personal Anti-Theft Guardian (Android app scaffold)

This is a **complete, buildable Android Studio project skeleton** for the
app we discussed: it runs on your own phone, and on a wrong-PIN pattern,
a SIM swap, or a shutdown attempt, it silently captures a photo (front or
rear camera) and/or a short audio clip, then delivers it — by upload when
there's connectivity, or by SMS location alert when there isn't.

This is **piece 1 of 3** from our conversation. The backend server and the
web dashboard (for remote "capture now" / "lock" / "wipe" / viewing
photos from any borrowed browser) are separate projects, not included
here yet — this app is built to talk to that backend once it exists
(see `remote/CommandPoller.kt`), but works stand-alone for the on-device
triggers (wrong PIN, SIM swap, shutdown) even without one.

## How to open and build it

1. Install **Android Studio** (Hedgehog or newer).
2. Open this folder (`InnoPhil/`) as a project — File → Open.
3. Let Gradle sync (it will download CameraX, WorkManager, OkHttp).
4. Add a launcher icon via **File → New → Image Asset** (the manifest
   currently uses the default so it builds without one).
5. Connect a real Android phone (not the emulator — camera/SIM/shutdown
   behavior needs real hardware) with USB debugging on, and Run.

## What's implemented

| Piece | File | Status |
|---|---|---|
| Wrong-PIN trigger | `admin/InnoPhilDeviceAdminReceiver.kt` (`onPasswordFailed`) | Real OS callback, works |
| SIM-swap trigger | `triggers/SimChangeReceiver.kt` | Works, single-SIM; extend for dual-SIM |
| Shutdown-attempt trigger | `triggers/ShutdownReceiver.kt` | Best-effort, OEM-dependent timing |
| Silent photo capture | `capture/CameraCaptureHelper.kt` (CameraX) | Works; shutter sound may still play on some OEMs/regions — see comment in file |
| Audio capture | `capture/AudioCaptureHelper.kt` | Works; **off by default is recommended** — see legal note below |
| Offline-safe upload queue | `network/UploadWorker.kt` + `NetworkStateReceiver.kt` | Works once you point `backend_url` at a real server |
| SMS location alert | `sms/SmsAlertSender.kt` | Works on any active SIM with signal, no data plan needed |
| Wi-Fi auto-join | `network/WifiAutoJoin.kt` | Honestly gated — silent force-on only works Android ≤9; see comments |
| Remote commands (capture/lock/wipe) | `remote/CommandPoller.kt` | **Stub** — needs the backend from piece 2 |
| Onboarding UI | `SetupActivity.kt` | Functional minimal flow: permissions → device admin → save |
| In-app update checker | `update/UpdateChecker.kt`, `update/ApkInstaller.kt` | Works — see "Getting updates" below |

## Getting updates without going back through GitHub manually

1. On the setup screen, fill in **GitHub repo** as `yourusername/InnoPhil`
   and tap **Check for updates** once, so it's saved.
2. From then on, every time you (or I, in a future chat) push a code
   change to this repo, GitHub Actions automatically builds it and
   publishes a numbered **Release** (`v2`, `v3`, ...) with the APK
   attached.
3. Every time you open InnoPhil, it silently asks GitHub "is there a
   newer release than what I'm running?" If yes, it downloads it and
   shows Android's install prompt — one tap and you're updated. If not,
   it says nothing.
4. You still need to tap "Install" on Android's own confirmation screen
   each time — that one tap can't be skipped for apps installed outside
   Play Store; it's Android's own anti-malware safeguard, not a
   limitation of this app specifically.

## Before you rely on this for real

- **Test on your actual phone.** Redmi/MIUI-HyperOS devices in particular
  apply their own aggressive background-service killing on top of stock
  Android — during setup, go to Settings → Battery → App battery saver →
  set InnoPhil to "No restrictions," or the service may get killed by the
  OS regardless of what the code does.
- **The camera-in-use indicator (green dot) will still show** on Android
  9+ whenever capture runs. This is enforced by the OS itself and cannot
  be suppressed by any app — flagged earlier in our conversation, still
  true here.
- **A powered-off phone cannot be woken by this or any app.** Hardware
  limit, not fixed by more code.
- **Audio recording carries real legal exposure** in some jurisdictions
  (all-party consent laws) if it ever captures someone else's
  conversation, even on your own stolen device. Consider shipping with
  `AudioCaptureHelper` wired to the remote "capture now" command only,
  not to the automatic triggers, until you've checked your local law.
- **This is for your own device only.** Installing anything like this on
  someone else's phone without their knowledge is illegal stalkerware in
  most jurisdictions, and Google Play policy (and Android's own Play
  Protect scanning) actively looks for exactly this permission
  combination for that reason.

## Suggested next step

Piece 2 (backend) needs, at minimum: an `/api/upload` endpoint (multipart
file receiver), an `/api/commands/pending` endpoint (polling target for
`CommandPoller.kt`), and simple token-based auth per device. Firebase
(Firestore + Storage + Cloud Functions) is the fastest way to stand this
up without managing a server yourself; a small Node.js/Express + S3
setup is the more portable alternative. Happy to scaffold either once
you're ready for that piece.
